import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import CVTemplateSelector from '@/components/cv-builder/CVTemplateSelector';
import CVForm from '@/components/cv-builder/CVForm';
import CVPreview from '@/components/cv-builder/CVPreview';
import { ArrowLeft, Save, Download, Eye, CheckCircle, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export interface CVData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedIn: string;
    website: string;
    summary: string;
  };
  experience: Array<{
    id: string;
    company: string;
    position: string;
    location: string;
    startDate: string;
    endDate: string;
    current: boolean;
    description: string;
  }>;
  education: Array<{
    id: string;
    institution: string;
    degree: string;
    field: string;
    startDate: string;
    endDate: string;
    gpa?: string;
  }>;
  skills: string[];
  certifications: Array<{
    id: string;
    name: string;
    issuer: string;
    date: string;
    expiryDate?: string;
  }>;
}

const CVBuilder = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState<'template' | 'form' | 'preview'>('template');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [atsScore, setAtsScore] = useState<number>(0);
  const [humanizedScore, setHumanizedScore] = useState<number>(0);
  const [showPreview, setShowPreview] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [cvData, setCvData] = useState<CVData>({
    personalInfo: {
      fullName: '',
      email: '',
      phone: '',
      location: '',
      linkedIn: '',
      website: '',
      summary: ''
    },
    experience: [],
    education: [],
    skills: [],
    certifications: []
  });

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    setCurrentStep('form');
  };

  const handleBackToTemplates = () => {
    setCurrentStep('template');
  };

  const handleAnalyzeCV = async () => {
    setIsAnalyzing(true);
    // Simulate ATS and humanized analysis
    setTimeout(() => {
      // Mock analysis - in real app, this would call an AI service
      const mockAtsScore = Math.floor(Math.random() * 20) + 80; // 80-100
      const mockHumanScore = Math.floor(Math.random() * 25) + 75; // 75-100
      setAtsScore(mockAtsScore);
      setHumanizedScore(mockHumanScore);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleGenerateWithAI = async () => {
    setIsGenerating(true);
    // Simulate AI generation
    setTimeout(() => {
      // Mock AI-generated data
      const aiGeneratedData: CVData = {
        personalInfo: {
          fullName: cvData.personalInfo.fullName || 'John Doe',
          email: cvData.personalInfo.email || 'john.doe@email.com',
          phone: cvData.personalInfo.phone || '+1 (555) 123-4567',
          location: cvData.personalInfo.location || 'New York, NY',
          linkedIn: cvData.personalInfo.linkedIn || 'linkedin.com/in/johndoe',
          website: cvData.personalInfo.website || 'johndoe.dev',
          summary: 'Experienced software engineer with 5+ years developing scalable web applications. Proficient in React, Node.js, and cloud technologies. Strong problem-solving skills with a passion for creating efficient, user-friendly solutions.'
        },
        experience: [
          {
            id: '1',
            company: 'Tech Solutions Inc.',
            position: 'Senior Software Engineer',
            location: 'New York, NY',
            startDate: '2022-03',
            endDate: '',
            current: true,
            description: '• Led development of microservices architecture serving 1M+ users\n• Improved application performance by 40% through code optimization\n• Mentored junior developers and conducted code reviews\n• Collaborated with product teams to deliver features on schedule'
          },
          {
            id: '2',
            company: 'StartupCorp',
            position: 'Full Stack Developer',
            location: 'San Francisco, CA',
            startDate: '2020-01',
            endDate: '2022-02',
            current: false,
            description: '• Built responsive web applications using React and Node.js\n• Implemented RESTful APIs and database optimization\n• Reduced load times by 60% through performance enhancements\n• Worked in agile environment with cross-functional teams'
          }
        ],
        education: [
          {
            id: '1',
            institution: 'University of Technology',
            degree: 'Bachelor of Science',
            field: 'Computer Science',
            startDate: '2016-09',
            endDate: '2020-05',
            gpa: '3.8'
          }
        ],
        skills: [
          'JavaScript', 'TypeScript', 'React', 'Node.js', 'Python', 'AWS', 
          'Docker', 'MongoDB', 'PostgreSQL', 'Git', 'Agile/Scrum', 'REST APIs'
        ],
        certifications: [
          {
            id: '1',
            name: 'AWS Certified Solutions Architect',
            issuer: 'Amazon Web Services',
            date: '2023-06',
            expiryDate: '2026-06'
          }
        ]
      };
      setCvData(aiGeneratedData);
      setIsGenerating(false);
    }, 3000);
  };

  const handleSaveCV = () => {
    // TODO: Implement save functionality
    console.log('Saving CV:', cvData);
  };

  const handleDownloadCV = () => {
    // TODO: Implement PDF download
    console.log('Downloading CV:', cvData);
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'template':
        return <CVTemplateSelector onSelectTemplate={handleTemplateSelect} />;
      case 'form':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <CVForm cvData={cvData} onDataChange={setCvData} />
            </div>
            <div className="hidden lg:block">
              <CVPreview cvData={cvData} templateId={selectedTemplate} />
            </div>
          </div>
        );
      case 'preview':
        return <CVPreview cvData={cvData} templateId={selectedTemplate} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-xl font-semibold text-gray-900">CV Builder</h1>
              
              {/* Template indicator and change button */}
              {selectedTemplate && currentStep !== 'template' && (
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-xs">
                    Current Template
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleBackToTemplates}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    Change Template
                  </Button>
                </div>
              )}
            </div>
            
            {currentStep !== 'template' && (
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setShowPreview(!showPreview)}
                  className="lg:hidden"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </Button>
                
                {/* AI Generate Button */}
                <Button
                  variant="outline"
                  onClick={handleGenerateWithAI}
                  disabled={isGenerating}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 hover:from-purple-600 hover:to-pink-600"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      AI Generate
                    </>
                  )}
                </Button>
                
                {/* ATS Check Button */}
                <Button
                  variant="outline"
                  onClick={handleAnalyzeCV}
                  disabled={isAnalyzing}
                  className="bg-green-600 text-white border-0 hover:bg-green-700"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      ATS Check
                    </>
                  )}
                </Button>
                
                <Button variant="outline" onClick={handleSaveCV}>
                  <Save className="w-4 h-4 mr-2" />
                  Save CV
                </Button>
                <Button onClick={handleDownloadCV}>
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ATS and Humanized Scores Display */}
      {(atsScore > 0 || humanizedScore > 0) && currentStep !== 'template' && (
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-center space-x-8">
              {atsScore > 0 && (
                <div className="flex items-center space-x-2">
                  <div className="text-sm font-medium text-gray-700">ATS Score:</div>
                  <div className={`text-lg font-bold ${
                    atsScore >= 90 ? 'text-green-600' : 
                    atsScore >= 80 ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {atsScore}%
                  </div>
                  <Badge className={
                    atsScore >= 90 ? 'bg-green-100 text-green-800' : 
                    atsScore >= 80 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                  }>
                    {atsScore >= 90 ? 'Excellent' : atsScore >= 80 ? 'Good' : 'Needs Work'}
                  </Badge>
                </div>
              )}
              
              {humanizedScore > 0 && (
                <div className="flex items-center space-x-2">
                  <div className="text-sm font-medium text-gray-700">Human Appeal:</div>
                  <div className={`text-lg font-bold ${
                    humanizedScore >= 90 ? 'text-green-600' : 
                    humanizedScore >= 80 ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {humanizedScore}%
                  </div>
                  <Badge className={
                    humanizedScore >= 90 ? 'bg-green-100 text-green-800' : 
                    humanizedScore >= 80 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                  }>
                    {humanizedScore >= 90 ? 'Excellent' : humanizedScore >= 80 ? 'Good' : 'Needs Work'}
                  </Badge>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentStep()}
      </div>

      {/* Mobile Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 lg:hidden">
          <div className="absolute inset-4 bg-white rounded-lg overflow-hidden">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold">CV Preview</h3>
              <Button variant="ghost" onClick={() => setShowPreview(false)}>
                ×
              </Button>
            </div>
            <div className="p-4 overflow-auto h-full">
              <CVPreview cvData={cvData} templateId={selectedTemplate} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CVBuilder;
