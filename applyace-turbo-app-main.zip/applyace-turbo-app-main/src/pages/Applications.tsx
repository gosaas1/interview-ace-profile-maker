
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, Building, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const Applications = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [filter, setFilter] = useState('all');

  const applications = [
    {
      id: 1,
      company: 'Tech Corp',
      position: 'Senior Developer',
      location: 'San Francisco, CA',
      status: 'pending',
      appliedDate: '2024-01-15',
      salary: '$120k - $160k',
      notes: 'Applied through company website'
    },
    {
      id: 2,
      company: 'StartupXY',
      position: 'Product Manager',
      location: 'New York, NY',
      status: 'interview',
      appliedDate: '2024-01-10',
      salary: '$100k - $140k',
      notes: 'Phone interview scheduled for next week'
    },
    {
      id: 3,
      company: 'Big Company',
      position: 'Data Scientist',
      location: 'Seattle, WA',
      status: 'rejected',
      appliedDate: '2024-01-05',
      salary: '$110k - $150k',
      notes: 'Position filled internally'
    },
    {
      id: 4,
      company: 'Innovation Labs',
      position: 'UI/UX Designer',
      location: 'Austin, TX',
      status: 'pending',
      appliedDate: '2024-01-12',
      salary: '$80k - $110k',
      notes: 'Waiting for portfolio review'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'interview': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'offer': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleViewDetails = (application: any) => {
    toast({
      title: "Application Details",
      description: `Viewing details for ${application.position} at ${application.company}`,
    });
  };

  const handleEditApplication = (application: any) => {
    toast({
      title: "Edit Application",
      description: `Editing application for ${application.position}`,
    });
  };

  const handleAddNote = (application: any) => {
    toast({
      title: "Add Note",
      description: `Adding note to ${application.position} application`,
    });
  };

  const filteredApplications = filter === 'all' 
    ? applications 
    : applications.filter(app => app.status === filter);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-xl font-semibold text-gray-900">My Applications</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filter Tabs */}
        <div className="flex space-x-1 mb-8 bg-gray-100 p-1 rounded-lg w-fit">
          {['all', 'pending', 'interview', 'rejected'].map((status) => (
            <Button
              key={status}
              variant={filter === status ? "default" : "ghost"}
              onClick={() => setFilter(status)}
              className="capitalize"
            >
              {status}
            </Button>
          ))}
        </div>

        {/* Applications List */}
        <div className="space-y-6">
          {filteredApplications.map((application) => (
            <Card key={application.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">
                      {application.position}
                    </h3>
                    <div className="flex items-center text-gray-600 mb-2">
                      <Building className="w-4 h-4 mr-1" />
                      {application.company}
                    </div>
                  </div>
                  <Badge className={getStatusColor(application.status)}>
                    {application.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="w-4 h-4 mr-2" />
                    {application.location}
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Calendar className="w-4 h-4 mr-2" />
                    Applied: {new Date(application.appliedDate).toLocaleDateString()}
                  </div>
                  <div className="text-green-600 font-semibold">
                    {application.salary}
                  </div>
                </div>

                {application.notes && (
                  <p className="text-gray-700 mb-4">{application.notes}</p>
                )}

                <div className="flex space-x-3">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleViewDetails(application)}
                  >
                    View Details
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleEditApplication(application)}
                  >
                    Edit Application
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleAddNote(application)}
                  >
                    Add Note
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredApplications.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No applications found
              </h3>
              <p className="text-gray-600 mb-4">
                {filter === 'all' 
                  ? "You haven't applied to any jobs yet." 
                  : `No applications with status "${filter}".`}
              </p>
              <Button onClick={() => navigate('/job-search')}>
                Search for Jobs
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default Applications;
