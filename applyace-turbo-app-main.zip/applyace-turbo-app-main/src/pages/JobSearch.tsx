
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Search, MapPin, Briefcase, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const JobSearch = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');

  const jobListings = [
    {
      id: 1,
      title: 'Senior Frontend Developer',
      company: 'Tech Innovation Inc.',
      location: 'San Francisco, CA',
      type: 'Full-time',
      salary: '$120k - $160k',
      posted: '2 days ago',
      tags: ['React', 'TypeScript', 'Remote'],
      description: 'Join our dynamic team building cutting-edge web applications.'
    },
    {
      id: 2,
      title: 'Product Manager',
      company: 'StartupXY',
      location: 'New York, NY',
      type: 'Full-time',
      salary: '$100k - $140k',
      posted: '1 day ago',
      tags: ['Strategy', 'Analytics', 'Agile'],
      description: 'Lead product development and strategy for our growing platform.'
    },
    {
      id: 3,
      title: 'UX/UI Designer',
      company: 'Design Studio Pro',
      location: 'Los Angeles, CA',
      type: 'Contract',
      salary: '$80k - $110k',
      posted: '3 days ago',
      tags: ['Figma', 'User Research', 'Prototyping'],
      description: 'Create beautiful and intuitive user experiences.'
    }
  ];

  const handleSearch = () => {
    toast({
      title: "Search initiated",
      description: `Searching for "${searchTerm}" in ${location || 'all locations'}`,
    });
  };

  const handleApply = (jobTitle: string, company: string) => {
    toast({
      title: "Application started",
      description: `Applying to ${jobTitle} at ${company}`,
    });
    // In a real app, this would redirect to application form or process
    navigate('/applications');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-xl font-semibold text-gray-900">Job Search</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Find Your Dream Job</CardTitle>
            <CardDescription>Search through thousands of job opportunities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
                <Input
                  placeholder="e.g. Frontend Developer"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <Input
                  placeholder="e.g. San Francisco, CA"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <Button className="w-full" onClick={handleSearch}>
                  <Search className="w-4 h-4 mr-2" />
                  Search Jobs
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Job Listings */}
        <div className="space-y-6">
          {jobListings.map((job) => (
            <Card key={job.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">{job.title}</h3>
                    <p className="text-gray-600 font-medium">{job.company}</p>
                  </div>
                  <Button onClick={() => handleApply(job.title, job.company)}>
                    Apply Now
                  </Button>
                </div>
                
                <p className="text-gray-700 mb-4">{job.description}</p>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {job.location}
                  </div>
                  <div className="flex items-center">
                    <Briefcase className="w-4 h-4 mr-1" />
                    {job.type}
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {job.posted}
                  </div>
                  <div className="font-medium text-green-600">
                    {job.salary}
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {job.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default JobSearch;
