
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, TrendingUp, Users, Target, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const Analytics = () => {
  const navigate = useNavigate();

  const applicationData = [
    { month: 'Jan', applications: 12, responses: 3, interviews: 1 },
    { month: 'Feb', applications: 18, responses: 5, interviews: 2 },
    { month: 'Mar', applications: 24, responses: 8, interviews: 3 },
    { month: 'Apr', applications: 15, responses: 4, interviews: 1 },
  ];

  const statusData = [
    { name: 'Pending', value: 45, color: '#fbbf24' },
    { name: 'Interview', value: 25, color: '#10b981' },
    { name: 'Rejected', value: 25, color: '#ef4444' },
    { name: 'Offer', value: 5, color: '#3b82f6' },
  ];

  const responseTimeData = [
    { day: 'Mon', avgTime: 3.2 },
    { day: 'Tue', avgTime: 2.8 },
    { day: 'Wed', avgTime: 4.1 },
    { day: 'Thu', avgTime: 2.5 },
    { day: 'Fri', avgTime: 3.7 },
    { day: 'Sat', avgTime: 1.9 },
    { day: 'Sun', avgTime: 2.3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-xl font-semibold text-gray-900">Analytics</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Response Rate</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">33.3%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
              <p className="text-sm text-green-600 mt-2">+5.2% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Interview Rate</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">12.5%</p>
                </div>
                <Users className="w-8 h-8 text-blue-500" />
              </div>
              <p className="text-sm text-blue-600 mt-2">+2.1% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Success Rate</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">8.3%</p>
                </div>
                <Target className="w-8 h-8 text-purple-500" />
              </div>
              <p className="text-sm text-purple-600 mt-2">+1.5% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Response Time</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">2.8 days</p>
                </div>
                <Clock className="w-8 h-8 text-orange-500" />
              </div>
              <p className="text-sm text-orange-600 mt-2">-0.5 days from last month</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Application Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Application Trends</CardTitle>
              <CardDescription>Monthly application activity and outcomes</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={applicationData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="applications" fill="#3b82f6" name="Applications" />
                  <Bar dataKey="responses" fill="#10b981" name="Responses" />
                  <Bar dataKey="interviews" fill="#f59e0b" name="Interviews" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Application Status</CardTitle>
              <CardDescription>Current status of all applications</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Response Time Trends */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Average Response Time</CardTitle>
              <CardDescription>How quickly employers respond to your applications</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={responseTimeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} days`, 'Avg Response Time']} />
                  <Line type="monotone" dataKey="avgTime" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Insights */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Key Insights</CardTitle>
            <CardDescription>AI-powered recommendations to improve your job search</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">🎯 Optimize Application Timing</h4>
                <p className="text-blue-800">Your applications sent on Tuesday and Thursday get 40% more responses. Consider timing your applications accordingly.</p>
              </div>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">📈 Strong Performance</h4>
                <p className="text-green-800">Your response rate is 15% above average. Keep using the same application strategy!</p>
              </div>
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-semibold text-yellow-900 mb-2">💡 CV Improvement</h4>
                <p className="text-yellow-800">Adding more keywords related to your target roles could increase your ATS score by up to 25%.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Analytics;
