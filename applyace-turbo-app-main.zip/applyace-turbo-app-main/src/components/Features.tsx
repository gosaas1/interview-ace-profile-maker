
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const Features = () => {
  const features = [
    {
      title: "AI-Powered CV Optimization",
      description: "Our AI analyzes your CV and optimizes it for each job application, increasing your chances of getting noticed.",
      icon: "🤖",
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "One-Click Applications",
      description: "Apply to multiple jobs simultaneously with just one click. Save hours of repetitive work.",
      icon: "⚡",
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "Smart Job Matching",
      description: "Find the perfect opportunities with our intelligent matching algorithm that learns your preferences.",
      icon: "🎯",
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "Application Tracking",
      description: "Keep track of all your applications, responses, and interviews in one centralized dashboard.",
      icon: "📊",
      color: "from-orange-500 to-red-500"
    },
    {
      title: "Email Integration",
      description: "Connect your email for automated follow-ups and seamless communication with employers.",
      icon: "📧",
      color: "from-indigo-500 to-purple-500"
    },
    {
      title: "Success Analytics",
      description: "Get insights into your application performance and improve your job search strategy.",
      icon: "📈",
      color: "from-pink-500 to-rose-500"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need to Land Your Dream Job
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Powerful features designed to streamline your job search and maximize your success rate.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-gray-200 hover:border-gray-300">
              <CardHeader>
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <span className="text-2xl">{feature.icon}</span>
                </div>
                <CardTitle className="text-xl font-semibold text-gray-900">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
