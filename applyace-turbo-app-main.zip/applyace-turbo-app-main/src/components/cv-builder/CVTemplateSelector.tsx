import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, Star, Zap } from 'lucide-react';
import TemplatePreview from './TemplatePreview';

interface Template {
  id: string;
  name: string;
  description: string;
  preview: string;
  category: 'professional' | 'creative' | 'minimal' | 'executive' | 'technical';
  isPremium?: boolean;
  atsScore: number;
  popularity: number;
  features: string[];
}

const templates: Template[] = [
  // Professional Templates
  {
    id: 'modern-professional',
    name: 'Modern Professional',
    description: 'Clean, contemporary design perfect for business and tech roles',
    preview: '/api/placeholder/300/400',
    category: 'professional',
    atsScore: 95,
    popularity: 1,
    features: ['ATS Optimized', 'Clean Layout', 'Professional Fonts']
  },
  {
    id: 'corporate-executive',
    name: 'Corporate Executive',
    description: 'Sophisticated design for senior management positions',
    preview: '/api/placeholder/300/400',
    category: 'professional',
    atsScore: 92,
    popularity: 2,
    features: ['Executive Style', 'ATS Compliant', 'Leadership Focus']
  },
  {
    id: 'finance-professional',
    name: 'Finance Professional',
    description: 'Traditional format ideal for banking and finance roles',
    preview: '/api/placeholder/300/400',
    category: 'professional',
    atsScore: 94,
    popularity: 3,
    features: ['Conservative Design', 'ATS Friendly', 'Numbers Focus']
  },
  {
    id: 'consulting-expert',
    name: 'Consulting Expert',
    description: 'Strategic layout perfect for consulting positions',
    preview: '/api/placeholder/300/400',
    category: 'professional',
    atsScore: 93,
    popularity: 4,
    features: ['Strategic Layout', 'Problem-Solving Focus', 'ATS Optimized']
  },
  {
    id: 'sales-leader',
    name: 'Sales Leader',
    description: 'Results-driven template for sales professionals',
    preview: '/api/placeholder/300/400',
    category: 'professional',
    atsScore: 91,
    popularity: 5,
    features: ['Results Focused', 'Achievement Highlight', 'ATS Compliant']
  },
  // Technical Templates
  {
    id: 'software-engineer',
    name: 'Software Engineer',
    description: 'Tech-focused template for developers and engineers',
    preview: '/api/placeholder/300/400',
    category: 'technical',
    atsScore: 96,
    popularity: 6,
    features: ['Tech Stack Highlight', 'Project Showcase', 'ATS Optimized']
  },
  {
    id: 'data-scientist',
    name: 'Data Scientist',
    description: 'Analytics-focused design for data professionals',
    preview: '/api/placeholder/300/400',
    category: 'technical',
    atsScore: 94,
    popularity: 7,
    features: ['Skills Matrix', 'Project Portfolio', 'ATS Friendly']
  },
  {
    id: 'devops-engineer',
    name: 'DevOps Engineer',
    description: 'Infrastructure-focused template for DevOps roles',
    preview: '/api/placeholder/300/400',
    category: 'technical',
    atsScore: 93,
    popularity: 8,
    features: ['Tech Tools Focus', 'Automation Highlight', 'ATS Compliant']
  },
  {
    id: 'product-manager',
    name: 'Product Manager',
    description: 'Product-focused template for PM roles',
    preview: '/api/placeholder/300/400',
    category: 'technical',
    atsScore: 92,
    popularity: 9,
    features: ['Product Focus', 'Metrics Driven', 'ATS Optimized']
  },
  {
    id: 'cybersecurity-specialist',
    name: 'Cybersecurity Specialist',
    description: 'Security-focused template for cybersecurity professionals',
    preview: '/api/placeholder/300/400',
    category: 'technical',
    atsScore: 94,
    popularity: 10,
    features: ['Security Focus', 'Certifications Highlight', 'ATS Friendly']
  },
  // Creative Templates
  {
    id: 'creative-designer',
    name: 'Creative Designer',
    description: 'Visually striking template for design professionals',
    preview: '/api/placeholder/300/400',
    category: 'creative',
    atsScore: 85,
    popularity: 11,
    isPremium: true,
    features: ['Visual Appeal', 'Portfolio Integration', 'Creative Layout']
  },
  {
    id: 'marketing-specialist',
    name: 'Marketing Specialist',
    description: 'Brand-focused template for marketing professionals',
    preview: '/api/placeholder/300/400',
    category: 'creative',
    atsScore: 88,
    popularity: 12,
    features: ['Brand Focus', 'Campaign Highlight', 'ATS Compatible']
  },
  {
    id: 'content-creator',
    name: 'Content Creator',
    description: 'Story-driven template for content professionals',
    preview: '/api/placeholder/300/400',
    category: 'creative',
    atsScore: 86,
    popularity: 13,
    features: ['Content Focus', 'Social Media Integration', 'Creative Flair']
  },
  {
    id: 'ux-designer',
    name: 'UX Designer',
    description: 'User-centered template for UX/UI designers',
    preview: '/api/placeholder/300/400',
    category: 'creative',
    atsScore: 87,
    popularity: 14,
    isPremium: true,
    features: ['User-Centered', 'Design Process', 'Portfolio Ready']
  },
  // Minimal Templates
  {
    id: 'minimal-clean',
    name: 'Minimal Clean',
    description: 'Simple, elegant design that focuses on content',
    preview: '/api/placeholder/300/400',
    category: 'minimal',
    atsScore: 97,
    popularity: 15,
    features: ['Ultra Clean', 'Content Focus', 'Maximum ATS Score']
  },
  {
    id: 'scandinavian-minimal',
    name: 'Scandinavian Minimal',
    description: 'Nordic-inspired clean design',
    preview: '/api/placeholder/300/400',
    category: 'minimal',
    atsScore: 96,
    popularity: 16,
    features: ['Nordic Style', 'White Space', 'ATS Perfect']
  },
  {
    id: 'simple-elegance',
    name: 'Simple Elegance',
    description: 'Refined simplicity for any industry',
    preview: '/api/placeholder/300/400',
    category: 'minimal',
    atsScore: 95,
    popularity: 17,
    features: ['Timeless Design', 'Universal Appeal', 'ATS Optimized']
  },
  // Executive Templates
  {
    id: 'c-suite-executive',
    name: 'C-Suite Executive',
    description: 'Premium template for C-level executives',
    preview: '/api/placeholder/300/400',
    category: 'executive',
    atsScore: 90,
    popularity: 18,
    isPremium: true,
    features: ['Executive Presence', 'Leadership Focus', 'Premium Design']
  },
  {
    id: 'board-member',
    name: 'Board Member',
    description: 'Distinguished template for board positions',
    preview: '/api/placeholder/300/400',
    category: 'executive',
    atsScore: 89,
    popularity: 19,
    isPremium: true,
    features: ['Distinguished Look', 'Governance Focus', 'Premium Quality']
  },
  {
    id: 'senior-director',
    name: 'Senior Director',
    description: 'Authoritative template for senior leadership',
    preview: '/api/placeholder/300/400',
    category: 'executive',
    atsScore: 91,
    popularity: 20,
    features: ['Authority Design', 'Strategic Focus', 'ATS Compliant']
  }
];

interface CVTemplateSelectorProps {
  onSelectTemplate: (templateId: string) => void;
}

const CVTemplateSelector: React.FC<CVTemplateSelectorProps> = ({ onSelectTemplate }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('professional');
  
  const categories = [
    { id: 'professional', name: 'Professional', count: templates.filter(t => t.category === 'professional').length },
    { id: 'technical', name: 'Technical', count: templates.filter(t => t.category === 'technical').length },
    { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
    { id: 'minimal', name: 'Minimal', count: templates.filter(t => t.category === 'minimal').length },
    { id: 'executive', name: 'Executive', count: templates.filter(t => t.category === 'executive').length },
  ];

  const getATSColor = (score: number) => {
    if (score >= 95) return 'text-green-600 bg-green-100';
    if (score >= 90) return 'text-blue-600 bg-blue-100';
    return 'text-orange-600 bg-orange-100';
  };

  const getPopularityBadge = (popularity: number) => {
    if (popularity <= 5) return <Badge className="bg-red-500 text-white text-xs">🔥 Most Popular</Badge>;
    if (popularity <= 10) return <Badge className="bg-orange-500 text-white text-xs">⭐ Popular</Badge>;
    return null;
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Choose Your ATS-Compliant CV Template
        </h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-6">
          Select from our collection of 20 most popular, professionally designed templates. 
          All templates are optimized for Applicant Tracking Systems (ATS) to ensure your CV gets noticed.
        </p>
        <div className="flex justify-center space-x-8 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span>ATS Optimized</span>
          </div>
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-blue-600" />
            <span>Industry Specific</span>
          </div>
          <div className="flex items-center space-x-2">
            <Star className="w-5 h-5 text-yellow-600" />
            <span>Most Popular</span>
          </div>
        </div>
      </div>

      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
        <TabsList className="grid w-full grid-cols-5 mb-8">
          {categories.map(category => (
            <TabsTrigger 
              key={category.id} 
              value={category.id}
              className="text-sm font-medium"
            >
              {category.name} ({category.count})
            </TabsTrigger>
          ))}
        </TabsList>

        {categories.map(category => (
          <TabsContent key={category.id} value={category.id}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {templates
                .filter(template => template.category === category.id)
                .sort((a, b) => a.popularity - b.popularity)
                .map(template => (
                  <Card 
                    key={template.id} 
                    className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-2 hover:border-blue-300 relative overflow-hidden"
                  >
                    <CardHeader className="p-0">
                      <div className="relative">
                        <div className="aspect-[3/4] bg-gray-50 rounded-t-lg overflow-hidden">
                          <TemplatePreview 
                            templateId={template.id} 
                            className="w-full h-full transform scale-75 origin-top"
                          />
                        </div>
                        
                        {/* Badges */}
                        <div className="absolute top-2 left-2 flex flex-col space-y-1">
                          {getPopularityBadge(template.popularity)}
                          <Badge className={getATSColor(template.atsScore)}>
                            ATS {template.atsScore}%
                          </Badge>
                        </div>
                        
                        {template.isPremium && (
                          <Badge className="absolute top-2 right-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                            Premium
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="p-4">
                      <div className="mb-3">
                        <CardTitle className="text-lg mb-1 font-semibold">
                          {template.name}
                        </CardTitle>
                        <p className="text-sm text-gray-600 leading-relaxed">
                          {template.description}
                        </p>
                      </div>
                      
                      {/* Features */}
                      <div className="flex flex-wrap gap-1 mb-4">
                        {template.features.slice(0, 3).map(feature => (
                          <Badge 
                            key={feature} 
                            variant="outline" 
                            className="text-xs py-0 px-2 h-5"
                          >
                            {feature}
                          </Badge>
                        ))}
                      </div>
                      
                      <Button
                        onClick={() => onSelectTemplate(template.id)}
                        className="w-full group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 transition-all duration-300"
                        variant={template.isPremium ? "default" : "outline"}
                      >
                        {template.isPremium ? 'Use Premium Template' : 'Use This Template'}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default CVTemplateSelector;
