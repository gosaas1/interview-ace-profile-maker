
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CVData } from '@/pages/CVBuilder';
import { Mail, Phone, MapPin, Globe, Linkedin, Award, Calendar, Building } from 'lucide-react';

interface CVPreviewProps {
  cvData: CVData;
  templateId: string;
}

const CVPreview: React.FC<CVPreviewProps> = ({ cvData, templateId }) => {
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString + '-01');
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  const getTemplateInfo = (id: string) => {
    const templates: Record<string, { name: string; atsScore: number; category: string }> = {
      'modern-professional': { name: 'Modern Professional', atsScore: 95, category: 'professional' },
      'software-engineer': { name: 'Software Engineer', atsScore: 96, category: 'technical' },
      'minimal-clean': { name: 'Minimal Clean', atsScore: 97, category: 'minimal' },
      'creative-designer': { name: 'Creative Designer', atsScore: 85, category: 'creative' },
      'c-suite-executive': { name: 'C-Suite Executive', atsScore: 90, category: 'executive' },
    };
    return templates[id] || { name: 'Professional', atsScore: 95, category: 'professional' };
  };

  const renderProfessionalTemplate = () => (
    <div className="bg-white p-8 shadow-lg rounded-lg max-w-4xl mx-auto font-sans">
      {/* Header */}
      <div className="border-b-2 border-blue-600 pb-6 mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {cvData.personalInfo.fullName || 'Your Name'}
        </h1>
        <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
          {cvData.personalInfo.email && (
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-blue-600" />
              {cvData.personalInfo.email}
            </div>
          )}
          {cvData.personalInfo.phone && (
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-blue-600" />
              {cvData.personalInfo.phone}
            </div>
          )}
          {cvData.personalInfo.location && (
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              {cvData.personalInfo.location}
            </div>
          )}
          {cvData.personalInfo.linkedIn && (
            <div className="flex items-center gap-2">
              <Linkedin className="w-4 h-4 text-blue-600" />
              {cvData.personalInfo.linkedIn}
            </div>
          )}
        </div>
      </div>

      {/* Professional Summary */}
      {cvData.personalInfo.summary && (
        <div className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 mb-3 uppercase tracking-wide">Professional Summary</h2>
          <p className="text-gray-700 leading-relaxed">{cvData.personalInfo.summary}</p>
        </div>
      )}

      {/* Experience */}
      {cvData.experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 mb-4 uppercase tracking-wide">Professional Experience</h2>
          <div className="space-y-4">
            {cvData.experience.map(exp => (
              <div key={exp.id} className="border-l-4 border-blue-200 pl-4">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-bold text-gray-900 text-lg">{exp.position}</h3>
                  <span className="text-sm text-gray-600 font-medium bg-gray-100 px-2 py-1 rounded">
                    {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                  </span>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <Building className="w-4 h-4 text-blue-600" />
                  <span className="font-semibold text-gray-800">{exp.company}</span>
                  {exp.location && (
                    <>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-600">{exp.location}</span>
                    </>
                  )}
                </div>
                {exp.description && (
                  <div className="text-gray-700 text-sm leading-relaxed whitespace-pre-line ml-6">
                    {exp.description}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {cvData.education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 mb-4 uppercase tracking-wide">Education</h2>
          <div className="space-y-3">
            {cvData.education.map(edu => (
              <div key={edu.id} className="bg-gray-50 p-3 rounded">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-bold text-gray-900">{edu.degree} in {edu.field}</h3>
                  <span className="text-sm text-gray-600 font-medium">
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-800 font-medium">{edu.institution}</span>
                  {edu.gpa && (
                    <>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-600">GPA: {edu.gpa}</span>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {cvData.skills.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 mb-3 uppercase tracking-wide">Core Skills</h2>
          <div className="grid grid-cols-3 gap-2">
            {cvData.skills.map(skill => (
              <Badge key={skill} className="bg-blue-100 text-blue-800 font-medium text-center justify-center py-1">
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Certifications */}
      {cvData.certifications.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 mb-4 uppercase tracking-wide">Certifications</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {cvData.certifications.map(cert => (
              <div key={cert.id} className="flex items-start space-x-3 bg-gray-50 p-3 rounded">
                <Award className="w-5 h-5 text-blue-600 mt-1" />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{cert.name}</h3>
                  <p className="text-gray-600 text-sm">{cert.issuer}</p>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <Calendar className="w-3 h-3 mr-1" />
                    {formatDate(cert.date)}
                    {cert.expiryDate && ` - ${formatDate(cert.expiryDate)}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderTechnicalTemplate = () => (
    <div className="bg-white p-8 shadow-lg rounded-lg max-w-4xl mx-auto font-mono">
      {/* Header */}
      <div className="border-b border-gray-300 pb-4 mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 font-sans">
          {cvData.personalInfo.fullName || 'Your Name'}
        </h1>
        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
          {cvData.personalInfo.email && (
            <span>📧 {cvData.personalInfo.email}</span>
          )}
          {cvData.personalInfo.phone && (
            <span>📱 {cvData.personalInfo.phone}</span>
          )}
          {cvData.personalInfo.location && (
            <span>📍 {cvData.personalInfo.location}</span>
          )}
          {cvData.personalInfo.linkedIn && (
            <span>💼 {cvData.personalInfo.linkedIn}</span>
          )}
        </div>
      </div>

      {/* Summary */}
      {cvData.personalInfo.summary && (
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-2 font-sans">// SUMMARY</h2>
          <p className="text-gray-700 leading-relaxed font-sans text-sm">{cvData.personalInfo.summary}</p>
        </div>
      )}

      {/* Technical Skills First */}
      {cvData.skills.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-3 font-sans">// TECHNICAL_SKILLS</h2>
          <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
            <div className="grid grid-cols-2 gap-4">
              {cvData.skills.map((skill, index) => (
                <div key={skill} className="flex items-center">
                  <span className="text-gray-500 mr-2">{String(index + 1).padStart(2, '0')}.</span>
                  <span>{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Experience */}
      {cvData.experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4 font-sans">// WORK_EXPERIENCE</h2>
          <div className="space-y-4">
            {cvData.experience.map(exp => (
              <div key={exp.id} className="border border-gray-200 p-4 rounded">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-gray-900 font-sans">{exp.position}</h3>
                  <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                    {formatDate(exp.startDate)} → {exp.current ? 'current' : formatDate(exp.endDate)}
                  </code>
                </div>
                <div className="text-sm text-gray-600 mb-2 font-sans">
                  <strong>{exp.company}</strong> {exp.location && `• ${exp.location}`}
                </div>
                {exp.description && (
                  <div className="text-gray-700 text-sm leading-relaxed whitespace-pre-line font-sans">
                    {exp.description}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {cvData.education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4 font-sans">// EDUCATION</h2>
          <div className="space-y-2">
            {cvData.education.map(edu => (
              <div key={edu.id} className="flex justify-between items-start">
                <div className="font-sans">
                  <h3 className="font-semibold text-gray-900">{edu.degree} in {edu.field}</h3>
                  <p className="text-gray-600 text-sm">{edu.institution}</p>
                </div>
                <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                  {formatDate(edu.startDate)} → {formatDate(edu.endDate)}
                </code>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Certifications */}
      {cvData.certifications.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4 font-sans">// CERTIFICATIONS</h2>
          <div className="space-y-2">
            {cvData.certifications.map(cert => (
              <div key={cert.id} className="flex justify-between items-start font-sans">
                <div>
                  <h3 className="font-medium text-gray-900">{cert.name}</h3>
                  <p className="text-gray-600 text-sm">{cert.issuer}</p>
                </div>
                <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                  {formatDate(cert.date)}
                </code>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderMinimalTemplate = () => (
    <div className="bg-white p-12 shadow-lg rounded-lg max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-light text-gray-900 mb-4">
          {cvData.personalInfo.fullName || 'Your Name'}
        </h1>
        <div className="flex justify-center space-x-8 text-sm text-gray-600">
          {cvData.personalInfo.email && <span>{cvData.personalInfo.email}</span>}
          {cvData.personalInfo.phone && <span>{cvData.personalInfo.phone}</span>}
          {cvData.personalInfo.location && <span>{cvData.personalInfo.location}</span>}
        </div>
      </div>

      {/* Summary */}
      {cvData.personalInfo.summary && (
        <div className="mb-12 text-center">
          <p className="text-gray-700 leading-relaxed max-w-3xl mx-auto">
            {cvData.personalInfo.summary}
          </p>
        </div>
      )}

      {/* Experience */}
      {cvData.experience.length > 0 && (
        <div className="mb-12">
          <h2 className="text-xl font-light text-gray-900 mb-8 text-center uppercase tracking-wider">
            Experience
          </h2>
          <div className="space-y-8">
            {cvData.experience.map(exp => (
              <div key={exp.id} className="text-center">
                <h3 className="font-medium text-gray-900 text-lg mb-1">{exp.position}</h3>
                <div className="text-gray-600 mb-2">
                  {exp.company} • {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                </div>
                {exp.description && (
                  <p className="text-gray-700 text-sm max-w-2xl mx-auto leading-relaxed">
                    {exp.description.split('\n')[0]}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {cvData.education.length > 0 && (
        <div className="mb-12">
          <h2 className="text-xl font-light text-gray-900 mb-8 text-center uppercase tracking-wider">
            Education
          </h2>
          <div className="space-y-4 text-center">
            {cvData.education.map(edu => (
              <div key={edu.id}>
                <h3 className="font-medium text-gray-900">{edu.degree} in {edu.field}</h3>
                <div className="text-gray-600 text-sm">
                  {edu.institution} • {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {cvData.skills.length > 0 && (
        <div className="mb-12">
          <h2 className="text-xl font-light text-gray-900 mb-8 text-center uppercase tracking-wider">
            Skills
          </h2>
          <div className="flex flex-wrap justify-center gap-3 max-w-2xl mx-auto">
            {cvData.skills.map(skill => (
              <span key={skill} className="text-gray-700 text-sm border-b border-gray-300 pb-1">
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderTemplate = () => {
    if (templateId.includes('technical') || templateId.includes('software') || templateId.includes('data') || templateId.includes('devops')) {
      return renderTechnicalTemplate();
    } else if (templateId.includes('minimal') || templateId.includes('clean')) {
      return renderMinimalTemplate();
    } else {
      return renderProfessionalTemplate();
    }
  };

  const templateInfo = getTemplateInfo(templateId);

  return (
    <Card className="h-fit sticky top-8">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Live Preview</h3>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-xs">
              {templateInfo.name}
            </Badge>
            <Badge className={`text-xs ${templateInfo.atsScore >= 95 ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
              ATS {templateInfo.atsScore}%
            </Badge>
          </div>
        </div>
        <div className="scale-40 origin-top-left w-[250%] h-fit overflow-hidden">
          {renderTemplate()}
        </div>
      </CardContent>
    </Card>
  );
};

export default CVPreview;
