
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Mail, Phone, MapPin, Globe, Linkedin, Award, Calendar, Building } from 'lucide-react';

interface TemplatePreviewProps {
  templateId: string;
  className?: string;
}

const TemplatePreview: React.FC<TemplatePreviewProps> = ({ templateId, className = "" }) => {
  // Sample data for preview
  const sampleData = {
    personalInfo: {
      fullName: 'John Smith',
      email: 'john.smith@email.com',
      phone: '+1 (555) 123-4567',
      location: 'New York, NY',
      linkedIn: 'linkedin.com/in/johnsmith',
      website: 'johnsmith.dev',
      summary: 'Experienced professional with 5+ years in technology and business development.'
    },
    experience: [
      {
        id: '1',
        company: 'Tech Corp',
        position: 'Senior Developer',
        location: 'New York, NY',
        startDate: '2022-01',
        endDate: '',
        current: true,
        description: '• Led development of key features\n• Improved system performance by 40%'
      },
      {
        id: '2',
        company: 'StartupXYZ',
        position: 'Software Engineer',
        location: 'San Francisco, CA',
        startDate: '2020-06',
        endDate: '2021-12',
        current: false,
        description: '• Built scalable web applications\n• Collaborated with cross-functional teams'
      }
    ],
    education: [
      {
        id: '1',
        institution: 'University of Technology',
        degree: 'Bachelor of Science',
        field: 'Computer Science',
        startDate: '2016-09',
        endDate: '2020-05',
        gpa: '3.8'
      }
    ],
    skills: ['JavaScript', 'React', 'Node.js', 'Python', 'AWS', 'Docker'],
    certifications: [
      {
        id: '1',
        name: 'AWS Certified Developer',
        issuer: 'Amazon Web Services',
        date: '2023-06',
        expiryDate: '2026-06'
      }
    ]
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString + '-01');
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  // Professional Templates (5 unique designs)
  const renderModernProfessional = () => (
    <div className={`bg-white p-4 shadow-sm rounded border ${className}`}>
      <div className="border-b-2 border-blue-600 pb-3 mb-3">
        <h1 className="text-lg font-bold text-gray-900 mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
          <div className="flex items-center gap-1">
            <Mail className="w-2 h-2 text-blue-600" />
            <span className="truncate">{sampleData.personalInfo.email}</span>
          </div>
          <div className="flex items-center gap-1">
            <Phone className="w-2 h-2 text-blue-600" />
            <span>{sampleData.personalInfo.phone}</span>
          </div>
        </div>
      </div>
      <div className="mb-3">
        <h2 className="text-sm font-bold text-blue-600 mb-1 uppercase">Summary</h2>
        <p className="text-xs text-gray-700 leading-tight">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="mb-3">
        <h2 className="text-sm font-bold text-blue-600 mb-2 uppercase">Experience</h2>
        <div className="space-y-2">
          {sampleData.experience.slice(0, 2).map(exp => (
            <div key={exp.id} className="border-l-2 border-blue-200 pl-2">
              <h3 className="font-semibold text-gray-900 text-xs">{exp.position}</h3>
              <div className="text-xs text-gray-800 font-medium mb-1">{exp.company}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCorporateExecutive = () => (
    <div className={`bg-gradient-to-r from-gray-900 to-gray-700 text-white p-4 shadow-sm rounded ${className}`}>
      <div className="text-center mb-3">
        <h1 className="text-lg font-bold mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-gray-300">SENIOR EXECUTIVE</div>
        <div className="text-xs text-gray-400 mt-1">{sampleData.personalInfo.email}</div>
      </div>
      <div className="bg-white/10 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-white mb-1">EXECUTIVE SUMMARY</h2>
        <p className="text-xs text-gray-200 leading-tight">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <h2 className="text-sm font-bold text-white mb-1">LEADERSHIP</h2>
          <div className="text-xs text-gray-300">Senior Developer</div>
        </div>
        <div>
          <h2 className="text-sm font-bold text-white mb-1">EXPERTISE</h2>
          <div className="flex flex-wrap gap-1">
            {sampleData.skills.slice(0, 3).map(skill => (
              <Badge key={skill} className="bg-white/20 text-white text-xs px-1 py-0 h-4">
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderFinanceProfessional = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-2 border-green-800 ${className}`}>
      <div className="bg-green-800 text-white p-2 -m-4 mb-3 rounded-t">
        <h1 className="text-lg font-bold text-center">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-center text-green-200">FINANCE PROFESSIONAL</div>
      </div>
      <div className="mt-3">
        <div className="grid grid-cols-2 gap-2 text-xs mb-3">
          <div>📧 {sampleData.personalInfo.email}</div>
          <div>📱 {sampleData.personalInfo.phone}</div>
        </div>
        <h2 className="text-sm font-bold text-green-800 mb-1 border-b border-green-200">EXPERIENCE</h2>
        <div className="text-xs text-gray-700 mb-2">
          <strong>Senior Developer</strong> - Tech Corp
        </div>
        <h2 className="text-sm font-bold text-green-800 mb-1 border-b border-green-200">KEY SKILLS</h2>
        <div className="text-xs text-gray-700">
          {sampleData.skills.slice(0, 4).join(' • ')}
        </div>
      </div>
    </div>
  );

  const renderConsultingExpert = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-l-8 border-indigo-600 ${className}`}>
      <div className="flex justify-between items-start mb-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">{sampleData.personalInfo.fullName}</h1>
          <div className="text-xs text-indigo-600 font-semibold">STRATEGIC CONSULTANT</div>
        </div>
        <div className="text-right text-xs text-gray-600">
          <div>{sampleData.personalInfo.phone}</div>
          <div>{sampleData.personalInfo.email}</div>
        </div>
      </div>
      <div className="bg-indigo-50 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-indigo-800 mb-1">STRATEGIC OVERVIEW</h2>
        <p className="text-xs text-gray-700 leading-tight">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="grid grid-cols-3 gap-2 text-xs">
        <div>
          <h3 className="font-bold text-indigo-600">EXPERTISE</h3>
          <div className="text-gray-700">Technology</div>
        </div>
        <div>
          <h3 className="font-bold text-indigo-600">LOCATION</h3>
          <div className="text-gray-700">New York</div>
        </div>
        <div>
          <h3 className="font-bold text-indigo-600">EXPERIENCE</h3>
          <div className="text-gray-700">5+ Years</div>
        </div>
      </div>
    </div>
  );

  const renderSalesLeader = () => (
    <div className={`bg-gradient-to-br from-orange-500 to-red-500 text-white p-4 shadow-sm rounded ${className}`}>
      <div className="text-center mb-3">
        <h1 className="text-lg font-bold mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs bg-white/20 rounded px-2 py-1 inline-block">SALES LEADER</div>
      </div>
      <div className="bg-white text-gray-800 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-orange-600 mb-1">RESULTS DELIVERED</h2>
        <div className="text-xs">• 40% Performance Improvement</div>
        <div className="text-xs">• Tech Corp Leadership Role</div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="font-bold">CONTACT</div>
          <div className="text-orange-100">{sampleData.personalInfo.email}</div>
        </div>
        <div>
          <div className="font-bold">SKILLS</div>
          <div className="text-orange-100">{sampleData.skills.slice(0, 2).join(', ')}</div>
        </div>
      </div>
    </div>
  );

  // Technical Templates (5 unique designs)
  const renderSoftwareEngineer = () => (
    <div className={`bg-gray-900 text-green-400 p-4 shadow-sm rounded font-mono ${className}`}>
      <div className="border border-green-400 p-2 mb-3">
        <div className="text-center text-white">
          <h1 className="text-lg font-bold font-sans">{sampleData.personalInfo.fullName}</h1>
          <div className="text-xs text-green-400">$ ./software-engineer --senior</div>
        </div>
      </div>
      <div className="mb-3">
        <div className="text-sm text-green-300 mb-1"># Technical Stack</div>
        <div className="bg-black p-2 rounded text-xs">
          {sampleData.skills.slice(0, 4).map((skill, index) => (
            <div key={skill} className="flex items-center">
              <span className="text-gray-500 mr-2">{String(index + 1).padStart(2, '0')}.</span>
              <span>{skill}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="text-xs">
        <div className="text-green-300"># Contact Info</div>
        <div className="text-gray-400">
          📧 {sampleData.personalInfo.email}<br/>
          🔗 {sampleData.personalInfo.linkedIn}
        </div>
      </div>
    </div>
  );

  const renderDataScientist = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-2 border-purple-500 ${className}`}>
      <div className="bg-purple-500 text-white p-2 -m-4 mb-3 rounded-t">
        <h1 className="text-lg font-bold">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs">DATA SCIENTIST & ANALYST</div>
      </div>
      <div className="mt-3">
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="bg-purple-50 p-2 rounded">
            <div className="text-xs font-bold text-purple-700">ANALYTICS</div>
            <div className="text-xs text-gray-700">Python, R, SQL</div>
          </div>
          <div className="bg-purple-50 p-2 rounded">
            <div className="text-xs font-bold text-purple-700">ML/AI</div>
            <div className="text-xs text-gray-700">TensorFlow, PyTorch</div>
          </div>
        </div>
        <div className="text-xs text-gray-600 mb-2">
          <strong>Current:</strong> Senior Developer at Tech Corp
        </div>
        <div className="text-xs text-gray-600">
          📊 40% Performance Improvement • 🎓 Computer Science
        </div>
      </div>
    </div>
  );

  const renderDevOpsEngineer = () => (
    <div className={`bg-slate-800 text-white p-4 shadow-sm rounded ${className}`}>
      <div className="border-l-4 border-cyan-400 pl-3 mb-3">
        <h1 className="text-lg font-bold text-cyan-300">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-cyan-100">DevOps & Infrastructure Engineer</div>
        <div className="text-xs text-gray-400 mt-1">{sampleData.personalInfo.email}</div>
      </div>
      <div className="bg-slate-700 p-2 rounded mb-3">
        <div className="text-sm font-bold text-cyan-300 mb-1">INFRASTRUCTURE STACK</div>
        <div className="grid grid-cols-2 gap-1 text-xs">
          <div>☁️ AWS/Docker</div>
          <div>🔧 CI/CD Pipeline</div>
          <div>📊 Monitoring</div>
          <div>🔒 Security</div>
        </div>
      </div>
      <div className="text-xs text-gray-300">
        <div className="font-bold text-white">EXPERIENCE:</div>
        <div>Senior Developer - Tech Corp (Current)</div>
        <div>• Led infrastructure automation</div>
      </div>
    </div>
  );

  const renderProductManager = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-2 border-pink-500 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">{sampleData.personalInfo.fullName}</h1>
          <div className="text-xs text-pink-500 font-semibold">PRODUCT MANAGER</div>
        </div>
        <div className="w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
          PM
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="bg-pink-50 p-2 rounded">
          <div className="text-xs font-bold text-pink-700">PRODUCT IMPACT</div>
          <div className="text-xs text-gray-700">40% Growth</div>
        </div>
        <div className="bg-pink-50 p-2 rounded">
          <div className="text-xs font-bold text-pink-700">TEAM SIZE</div>
          <div className="text-xs text-gray-700">10+ Engineers</div>
        </div>
      </div>
      <div className="text-xs text-gray-600">
        <div className="mb-1">📱 {sampleData.personalInfo.phone}</div>
        <div>📧 {sampleData.personalInfo.email}</div>
      </div>
    </div>
  );

  const renderCybersecuritySpecialist = () => (
    <div className={`bg-red-900 text-white p-4 shadow-sm rounded border border-red-500 ${className}`}>
      <div className="text-center mb-3">
        <div className="text-red-400 text-xs mb-1">🔒 SECURITY CLEARANCE</div>
        <h1 className="text-lg font-bold">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-red-300">CYBERSECURITY SPECIALIST</div>
      </div>
      <div className="bg-red-800 p-2 rounded mb-3">
        <div className="text-sm font-bold text-red-200 mb-1">SECURITY DOMAINS</div>
        <div className="grid grid-cols-2 gap-1 text-xs">
          <div>🛡️ Threat Analysis</div>
          <div>🔍 Penetration Testing</div>
          <div>🔐 Encryption</div>
          <div>📋 Compliance</div>
        </div>
      </div>
      <div className="text-xs text-red-200">
        <div>📧 {sampleData.personalInfo.email}</div>
        <div>🏆 AWS Certified Security</div>
      </div>
    </div>
  );

  // Creative Templates (4 unique designs)
  const renderCreativeDesigner = () => (
    <div className={`bg-gradient-to-br from-purple-100 via-pink-50 to-blue-100 p-4 shadow-sm rounded ${className}`}>
      <div className="text-center mb-3 relative">
        <div className="absolute top-0 right-0 w-6 h-6 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full"></div>
        <h1 className="text-lg font-bold text-gray-900 mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-purple-600 bg-white/50 rounded px-2 py-1 inline-block">
          CREATIVE DESIGNER
        </div>
      </div>
      <div className="bg-white/70 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-purple-700 mb-1">Creative Vision</h2>
        <p className="text-xs text-gray-700 leading-tight">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="font-bold text-purple-600">PORTFOLIO</div>
          <div className="text-gray-700">johnsmith.dev</div>
        </div>
        <div>
          <div className="font-bold text-purple-600">CONTACT</div>
          <div className="text-gray-700">{sampleData.personalInfo.email}</div>
        </div>
      </div>
    </div>
  );

  const renderMarketingSpecialist = () => (
    <div className={`bg-yellow-400 p-4 shadow-sm rounded ${className}`}>
      <div className="bg-white p-2 rounded mb-3">
        <h1 className="text-lg font-bold text-gray-900 text-center">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-yellow-600 font-bold text-center">MARKETING SPECIALIST</div>
      </div>
      <div className="bg-yellow-500 text-white p-2 rounded mb-3">
        <div className="text-sm font-bold mb-1">CAMPAIGN RESULTS</div>
        <div className="text-xs">📈 40% Performance Boost</div>
        <div className="text-xs">🎯 Multi-platform Success</div>
      </div>
      <div className="text-xs text-gray-800">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <strong>Email:</strong> {sampleData.personalInfo.email}
          </div>
          <div>
            <strong>Phone:</strong> {sampleData.personalInfo.phone}
          </div>
        </div>
      </div>
    </div>
  );

  const renderContentCreator = () => (
    <div className={`bg-gradient-to-r from-teal-400 to-cyan-500 text-white p-4 shadow-sm rounded ${className}`}>
      <div className="text-center mb-3">
        <h1 className="text-lg font-bold mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs bg-white/20 rounded px-2 py-1 inline-block">CONTENT CREATOR</div>
      </div>
      <div className="bg-white/10 p-2 rounded mb-3">
        <div className="text-sm font-bold mb-1">CONTENT STRATEGY</div>
        <div className="text-xs">📝 Multi-platform storytelling</div>
        <div className="text-xs">📱 Social media optimization</div>
      </div>
      <div className="text-xs">
        <div className="mb-1">🌐 {sampleData.personalInfo.website}</div>
        <div>📧 {sampleData.personalInfo.email}</div>
      </div>
    </div>
  );

  const renderUXDesigner = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-2 border-blue-300 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <h1 className="text-lg font-bold text-gray-900">{sampleData.personalInfo.fullName}</h1>
          <div className="text-xs text-blue-500 font-semibold">UX/UI DESIGNER</div>
        </div>
        <div className="w-8 h-8 bg-blue-500 rounded text-white flex items-center justify-center text-xs font-bold">
          UX
        </div>
      </div>
      <div className="bg-blue-50 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-blue-700 mb-1">DESIGN PROCESS</h2>
        <div className="flex justify-between text-xs text-gray-700">
          <span>Research</span>
          <span>→</span>
          <span>Design</span>
          <span>→</span>
          <span>Test</span>
        </div>
      </div>
      <div className="text-xs text-gray-600">
        <div>🎨 Portfolio: {sampleData.personalInfo.website}</div>
        <div>📧 {sampleData.personalInfo.email}</div>
      </div>
    </div>
  );

  // Minimal Templates (3 unique designs)
  const renderMinimalClean = () => (
    <div className={`bg-white p-4 shadow-sm rounded ${className}`}>
      <div className="text-center mb-4">
        <h1 className="text-lg font-light text-gray-900 mb-2">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-gray-600 space-x-4">
          <span>{sampleData.personalInfo.email}</span>
          <span>{sampleData.personalInfo.phone}</span>
        </div>
      </div>
      <div className="mb-4 text-center">
        <p className="text-xs text-gray-700 leading-relaxed">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="text-center">
        <h2 className="text-sm font-light text-gray-900 mb-2 uppercase tracking-wider">Experience</h2>
        <div className="text-xs text-gray-700">
          <div className="font-medium">Senior Developer</div>
          <div>Tech Corp • 2022 - Present</div>
        </div>
      </div>
    </div>
  );

  const renderScandinavianMinimal = () => (
    <div className={`bg-gray-50 p-4 shadow-sm rounded ${className}`}>
      <div className="border-b border-gray-200 pb-3 mb-3">
        <h1 className="text-lg font-light text-gray-800">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-gray-500 mt-1">{sampleData.personalInfo.email}</div>
      </div>
      <div className="space-y-3">
        <div>
          <h2 className="text-sm text-gray-700 font-medium mb-1">About</h2>
          <p className="text-xs text-gray-600 leading-relaxed">{sampleData.personalInfo.summary}</p>
        </div>
        <div>
          <h2 className="text-sm text-gray-700 font-medium mb-1">Current Role</h2>
          <div className="text-xs text-gray-600">Senior Developer at Tech Corp</div>
        </div>
        <div>
          <h2 className="text-sm text-gray-700 font-medium mb-1">Skills</h2>
          <div className="text-xs text-gray-600">{sampleData.skills.slice(0, 3).join(', ')}</div>
        </div>
      </div>
    </div>
  );

  const renderSimpleElegance = () => (
    <div className={`bg-white p-4 shadow-sm rounded border border-gray-100 ${className}`}>
      <div className="mb-4">
        <h1 className="text-lg font-medium text-gray-900 mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="h-px bg-gray-300 w-12 mb-2"></div>
        <div className="text-xs text-gray-500">{sampleData.personalInfo.email}</div>
      </div>
      <div className="space-y-3 text-xs">
        <div>
          <div className="font-medium text-gray-700 mb-1">Summary</div>
          <div className="text-gray-600 leading-relaxed">{sampleData.personalInfo.summary}</div>
        </div>
        <div>
          <div className="font-medium text-gray-700 mb-1">Experience</div>
          <div className="text-gray-600">Senior Developer, Tech Corp</div>
        </div>
      </div>
    </div>
  );

  // Executive Templates (3 unique designs)
  const renderCSuiteExecutive = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-l-8 border-gold-500 ${className}`} style={{borderLeftColor: '#d4af37'}}>
      <div className="mb-4">
        <h1 className="text-lg font-bold text-gray-900 mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs font-semibold" style={{color: '#d4af37'}}>CHIEF EXECUTIVE OFFICER</div>
        <div className="text-xs text-gray-600 mt-1">{sampleData.personalInfo.email}</div>
      </div>
      <div className="bg-gray-50 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-gray-800 mb-1">EXECUTIVE LEADERSHIP</h2>
        <p className="text-xs text-gray-700 leading-tight">{sampleData.personalInfo.summary}</p>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="font-bold text-gray-700">EXPERIENCE</div>
          <div className="text-gray-600">15+ Years Leadership</div>
        </div>
        <div>
          <div className="font-bold text-gray-700">SPECIALIZATION</div>
          <div className="text-gray-600">Technology & Growth</div>
        </div>
      </div>
    </div>
  );

  const renderBoardMember = () => (
    <div className={`bg-navy-900 text-white p-4 shadow-sm rounded ${className}`} style={{backgroundColor: '#1e3a8a'}}>
      <div className="text-center mb-3">
        <h1 className="text-lg font-bold mb-1">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs text-blue-200">BOARD OF DIRECTORS</div>
      </div>
      <div className="border border-blue-300 p-2 rounded mb-3">
        <h2 className="text-sm font-bold text-blue-200 mb-1">GOVERNANCE EXPERTISE</h2>
        <div className="text-xs text-blue-100">Strategic oversight and corporate governance</div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="font-bold text-blue-200">CONTACT</div>
          <div className="text-blue-100">{sampleData.personalInfo.email}</div>
        </div>
        <div>
          <div className="font-bold text-blue-200">LOCATION</div>
          <div className="text-blue-100">{sampleData.personalInfo.location}</div>
        </div>
      </div>
    </div>
  );

  const renderSeniorDirector = () => (
    <div className={`bg-white p-4 shadow-sm rounded border-2 border-gray-400 ${className}`}>
      <div className="bg-gray-400 text-white p-2 -m-4 mb-3 rounded-t">
        <h1 className="text-lg font-bold">{sampleData.personalInfo.fullName}</h1>
        <div className="text-xs">SENIOR DIRECTOR</div>
      </div>
      <div className="mt-3">
        <div className="mb-3">
          <h2 className="text-sm font-bold text-gray-700 mb-1 border-b border-gray-300 pb-1">LEADERSHIP PROFILE</h2>
          <p className="text-xs text-gray-600 leading-tight">{sampleData.personalInfo.summary}</p>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <div className="font-bold text-gray-700">POSITION</div>
            <div className="text-gray-600">Senior Developer</div>
          </div>
          <div>
            <div className="font-bold text-gray-700">COMPANY</div>
            <div className="text-gray-600">Tech Corp</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTemplate = () => {
    switch (templateId) {
      // Professional Templates
      case 'modern-professional':
        return renderModernProfessional();
      case 'corporate-executive':
        return renderCorporateExecutive();
      case 'finance-professional':
        return renderFinanceProfessional();
      case 'consulting-expert':
        return renderConsultingExpert();
      case 'sales-leader':
        return renderSalesLeader();
      
      // Technical Templates
      case 'software-engineer':
        return renderSoftwareEngineer();
      case 'data-scientist':
        return renderDataScientist();
      case 'devops-engineer':
        return renderDevOpsEngineer();
      case 'product-manager':
        return renderProductManager();
      case 'cybersecurity-specialist':
        return renderCybersecuritySpecialist();
      
      // Creative Templates
      case 'creative-designer':
        return renderCreativeDesigner();
      case 'marketing-specialist':
        return renderMarketingSpecialist();
      case 'content-creator':
        return renderContentCreator();
      case 'ux-designer':
        return renderUXDesigner();
      
      // Minimal Templates
      case 'minimal-clean':
        return renderMinimalClean();
      case 'scandinavian-minimal':
        return renderScandinavianMinimal();
      case 'simple-elegance':
        return renderSimpleElegance();
      
      // Executive Templates
      case 'c-suite-executive':
        return renderCSuiteExecutive();
      case 'board-member':
        return renderBoardMember();
      case 'senior-director':
        return renderSeniorDirector();
      
      // Default fallback
      default:
        return renderModernProfessional();
    }
  };

  return renderTemplate();
};

export default TemplatePreview;
